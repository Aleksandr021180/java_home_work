package lesson8;

public interface Actions {

    void run();
    void jump();
}
