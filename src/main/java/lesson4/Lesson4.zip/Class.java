package lesson4;

public class Class {
    public static void main(String[]args){
        TicTacToe.turnGame();
    }
}

